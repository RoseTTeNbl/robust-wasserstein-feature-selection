# Robust feature selection: English manuscripts

Choose **XeLaTeX** as the compiler. **TeX Live 2025** is recommended for the
current cloud deployment. The default main document is `main.tex`.
Change the main-document setting to compile another entry:

| Entry | Manuscript |
| --- | --- |
| main.tex | English theory note |
| experiment_report.tex | English experimental report |

Only the two English manuscripts and their referenced English figures are
published online. Complete Chinese counterparts remain in the local repository
for reading and review; they are not part of this upload package.

Each entry is standalone. Its bibliography, if present, is inside the TeX file.
The shared figures/ directory contains only graphics referenced by these entries.
Local equivalent command: latexmk -xelatex main.tex (or another entry).

The entries default to TeX Live's TeX Gyre Termes, Cursor and Termes Math OTF files.
The first line defines
\RobustHWForceFallbackFonts, which avoids repeated system-font probes on the
cloud service. Delete that first line to restore the native-font preference;
the existing branches then use available Windows fonts or the open-font fallback.
No proprietary font files are included. The body, mathematical statements and
numerical results are copied
from their canonical manuscripts without editorial changes.

The unicode-math/mathtools compatibility warnings about bracket and colon
commands are retained in the build logs. The manuscripts do not use the affected
commands; no package import order or mathematical expression is changed.

The external packaging manifest records canonical hashes, packaged-file hashes,
body identity checks and any optional local compilation. It is provenance rather
than a manuscript entry. Uploading or replacing an Overleaf project is a separate
explicit operation; the packaging command itself does not publish anything.
