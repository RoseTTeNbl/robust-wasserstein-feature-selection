# Wasserstein robust variable selection: theory note

Compile `main.tex` using **pdfLaTeX** and BibTeX (TeX Live 2025 or later).
This package contains only the current English theory note. Experimental
design and code are maintained separately.

`main.tex` and `references.bib` exactly match the reviewed canonical files.
The source uses the newtx text and mathematics fonts included in TeX Live;
no proprietary fonts or external figures are needed. `latexmkrc` selects
pdfLaTeX; latexmk runs BibTeX when required. For a manual build, run
`pdflatex main`, `bibtex main`, then `pdflatex main` twice.

The packaging manifest is saved beside the ZIP, outside the uploaded
manuscript. Packaging does not upload or publish files.
